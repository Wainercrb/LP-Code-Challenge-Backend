import { injectable, inject } from 'inversify';
import { TYPES } from '../../../../types';
import { ResourceNotFound } from '../../../../libs/errors';
import { Cart, UnmarshalledCart } from '../../../../domain/cart';
import { User } from '../../../../domain/user';
import { CartRepository } from '../../../../domain/repository';
import { UserRepository } from '../../../../domain/repository';
// import { MemoryData } from '../memory-data'
// import { CartMapper } from '../mappers/cart'
import { SequelizeUser } from '../models/User';

@injectable()
export class UserSequelizeRepository implements UserRepository {
  //   @inject(TYPES.Database) private _database: MemoryData

  async signIn(): Promise<User> {
    console.log('entroooo');

    const data = await SequelizeUser.findOne({
      where: {
        username: 'admin',
      },
      raw: true,
    });

    console.log('data', data);

    // const cart = await this._database.cart.getById<UnmarshalledCart>(id)
    // if (!cart) {
    //   throw new ResourceNotFound('Cart', { id })
    // }
    return new Promise((resolve) => {
      resolve({} as User);
    });

    // return CartMapper.toDomain(cart)
  }
}
