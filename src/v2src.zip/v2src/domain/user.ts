import { Entity } from './entity';

export interface UnmarshalledUser {
  id?: string;
  username: string;
  password: string;
  balance: number;
}

export class User extends Entity<UnmarshalledUser> {
  private constructor(props: UnmarshalledUser) {
    const { id, ...data } = props;
    super(data, id);
  }

  public static create(props: UnmarshalledUser): User {
    const instance = new User(props);
    return instance;
  }

  public unmarshal(): UnmarshalledUser {
    return {
      id: this.id,
      username: this.username,
      password: this.password,
      balance: this.balance,
    };
  }

  get id(): string {
    return this._id;
  }

  get username(): string {
    return this.props.username;
  }

  get password(): string {
    return this.props.password;
  }

  get balance(): number {
    return this.props.balance;
  }
}
