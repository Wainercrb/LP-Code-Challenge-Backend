import { inject, injectable } from 'inversify'
import { TYPES } from '../types'
import { User } from '../domain/user'
import { UserRepository } from '../domain/repository'

@injectable()
export class UserService {
  @inject(TYPES.ItemRepository) private repository!: UserRepository

  public singIn(): Promise<User> {
    return this.repository.signIn()
  }
}
