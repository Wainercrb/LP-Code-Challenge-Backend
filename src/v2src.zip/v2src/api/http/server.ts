import express from 'express'
import cors from 'cors'
import { Request, Response } from 'express';
import { injectable, inject } from 'inversify';
import { TYPES } from '../../types';
import { Logger } from '../../infra/logging/pino';
// import { errorHandler, devErrorHandler } from './middlewares/error-handler';
import { HTTPRouter } from './router';
import cookieParser from 'cookie-parser';

export interface IServer {
  start(): void;
}

@injectable()
export class Server {
  @inject(TYPES.HTTPRouter) private _router!: HTTPRouter;
  @inject(TYPES.Logger) private _logger!: Logger;

  start(): void {
    const router = this._router.get();
    const logger = this._logger.get();
    const env = String(process.env);

    router.get('/robots.txt', (_req: Request, res: Response) => {
      // ctx.body = 'User-Agent: *\nDisallow: /'

      res.send('User-Agent: *\nDisallow: /');
    });

    router.get('/health', (_req: Request, res: Response) => {
      // ctx.body = 'OK'

      res.send('OK');
    });

    const app = express();

    app.use(cors())
    app.use(express.json());
    app.use(express.urlencoded({ extended: false }));
    app.use(cookieParser());

    // app.use(env === 'production' ? errorHandler : devErrorHandler);

    app.use(router);

    app.on('error', (err) => {
      if (process.env.NODE_ENV !== 'test') {
        logger.error(err);
      }
    });

    app.listen(3000);
  }
}
